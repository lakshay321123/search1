// Placeholder for fetch & parse respecting robots.txt
export async function fetchAndParse(url: string) {
  // TODO: implement readability extraction, PDF OCR fallback
  return { url, content: '...parsed text...' };
}
